// this is my code 
const readline = require("readline");
const input = readline.createInterface({
  input:process.stdin,
  output:process.stdout,
  
});

var  books =["godan","gawan"];


const EventEmitter =require("events")
const eventEmitter = new EventEmitter();


function fun(){ 
  input.question("1-a 2-b 3-c",(num)=>{
        if(num==1){
         console.log(books)
         return fun()
        }
        else if(num==2){
          input.question("please write the name of the book",(name)=>{
            books.push(name)
            
            // input.close();
            return fun()
          })
        }
        else{
          if(num==3){
            input.question("wants to exit",(option)=>{
                 if(option=="y"|| option=="Y"){
                  console.log("bye bye")
                  input.close((msg)=>{
                   
                  });
                 }
            })
          }else{
            console.log("You have selected an invalid entry so please press 1, 2 or 3")
            return fun()
          }
          
        }
      })
    }
      eventEmitter.on("user register",fun)
      eventEmitter.emit("user register")

